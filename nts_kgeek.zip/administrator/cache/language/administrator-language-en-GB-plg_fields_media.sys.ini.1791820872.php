<?php
defined('_JEXEC') or die;
return array (
  'PLG_FIELDS_MEDIA' => 'Fields - Media',
  'PLG_FIELDS_MEDIA_XML_DESCRIPTION' => 'This plugin lets you create new fields of type \'media\' in any extensions where custom fields are supported.',
);
