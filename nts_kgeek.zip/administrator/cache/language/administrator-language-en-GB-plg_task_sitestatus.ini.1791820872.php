<?php
defined('_JEXEC') or die;
return array (
  'PLG_TASK_SITE_STATUS' => 'Task - Site Status',
  'PLG_TASK_SITE_STATUS_DESC' => 'Toggles the site\'s status on each run.',
  'PLG_TASK_SITE_STATUS_ERROR_CONFIGURATION_PHP_NOTUNWRITABLE' => 'Could not make configuration.php un-writable.',
  'PLG_TASK_SITE_STATUS_ERROR_CONFIGURATION_PHP_NOTWRITABLE' => 'Could not make configuration.php writable.',
  'PLG_TASK_SITE_STATUS_ERROR_WRITE_FAILED' => 'Could not write to the configuration file!',
  'PLG_TASK_SITE_STATUS_ROUTINE_END_LOG_MESSAGE' => 'ToggleOffline return code is: %1$d. Processing Time: %2$.2f seconds.',
  'PLG_TASK_SITE_STATUS_TASK_LOG_SITE_STATUS' => 'Site was %1$s, is now %2$s.',
  'PLG_TASK_SITE_STATUS_SET_OFFLINE_DESC' => 'Sets site status to offline on each run.',
  'PLG_TASK_SITE_STATUS_SET_OFFLINE_ROUTINE_END_LOG_MESSAGE' => 'SetOffline return code is: %1$d. Processing Time: %2$.2f seconds.',
  'PLG_TASK_SITE_STATUS_SET_OFFLINE_TITLE' => 'Set Site Offline',
  'PLG_TASK_SITE_STATUS_SET_ONLINE_DESC' => 'Sets site status to online on each run.',
  'PLG_TASK_SITE_STATUS_SET_ONLINE_ROUTINE_END_LOG_MESSAGE' => 'SetOnline return code is: %1$d. Processing Time: %2$.2f seconds.',
  'PLG_TASK_SITE_STATUS_SET_ONLINE_TITLE' => 'Set Site Online',
  'PLG_TASK_SITE_STATUS_TITLE' => 'Toggle Offline',
  'PLG_TASK_SITE_STATUS_XML_DESCRIPTION' => 'Offers task routines to change the site\'s offline status.',
);
