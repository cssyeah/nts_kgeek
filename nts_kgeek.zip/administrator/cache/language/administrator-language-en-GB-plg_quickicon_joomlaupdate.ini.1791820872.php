<?php
defined('_JEXEC') or die;
return array (
  'PLG_QUICKICON_JOOMLAUPDATE' => 'Quick Icon - Joomla Update Notification',
  'PLG_QUICKICON_JOOMLAUPDATE_CHECKING' => 'Checking Joomla &hellip;',
  'PLG_QUICKICON_JOOMLAUPDATE_ERROR' => 'Unknown Joomla &hellip;',
  'PLG_QUICKICON_JOOMLAUPDATE_GROUP_DESC' => 'The group of this plugin (this value is compared with the group value used in <strong>Quick Icons</strong> modules to inject icons).',
  'PLG_QUICKICON_JOOMLAUPDATE_GROUP_LABEL' => 'Group',
  'PLG_QUICKICON_JOOMLAUPDATE_UPDATEFOUND' => '%s Available - Update now!',
  'PLG_QUICKICON_JOOMLAUPDATE_UPTODATE' => 'Joomla is up to date.',
  'PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION' => 'Checks for Joomla updates and notifies you when you visit the Home Dashboard page.',
);
