<?php
defined('_JEXEC') or die;
return array (
  'PLG_TASK_CHECK_FILES' => 'Task - Check Files',
  'PLG_TASK_CHECK_FILES_LABEL_DIMENSION_LIMIT' => 'Limit (px)',
  'PLG_TASK_CHECK_FILES_LABEL_MAXIMAGES' => 'Maximum Images',
  'PLG_TASK_CHECK_FILES_LABEL_MAXIMAGES_DESC' => 'The maximum number of images to be processed in a single run. Setting this number too high may cause the task to timeout.',
  'PLG_TASK_CHECK_FILES_LABEL_DIRECTORY' => 'Directory',
  'PLG_TASK_CHECK_FILES_LABEL_IMAGE_DIMENSION' => 'Dimension',
  'PLG_TASK_CHECK_FILES_LOG_IMAGE_PATH_NA' => 'Image path does not exist!',
  'PLG_TASK_CHECK_FILES_LOG_IMAGE_SAVE_FAIL' => 'Failed to save image file',
  'PLG_TASK_CHECK_FILES_LOG_RESIZE_FAIL' => 'Failed to resize image due to an error in plugin logic...',
  'PLG_TASK_CHECK_FILES_LOG_RESIZING_IMAGE' => 'Found image of size %1$sx%2$s px; resizing to %3$sx%4$s px. File: %5$s',
  'PLG_TASK_CHECK_FILES_TASK_IMAGE_SIZE_DESC' => 'Check images, resize if larger than allowed. Attention: The original file will be overwritten!',
  'PLG_TASK_CHECK_FILES_TASK_IMAGE_SIZE_TITLE' => 'Image Size Check',
  'PLG_TASK_CHECK_FILES_XML_DESCRIPTION' => 'Offers task routines for checking for oversized files, and related actions if possible.',
);
