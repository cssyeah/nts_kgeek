<?php
defined('_JEXEC') or die;
return array (
  'PLG_TASK_REQUESTS' => 'Task - Requests',
  'PLG_TASK_REQUESTS_BEARER' => 'Bearer',
  'PLG_TASK_REQUESTS_JOOMLA_TOKEN' => 'X-Joomla-Token',
  'PLG_TASK_REQUESTS_LABEL_AUTH' => 'Authorization',
  'PLG_TASK_REQUESTS_LABEL_AUTH_HEADER' => 'Authorization Header',
  'PLG_TASK_REQUESTS_LABEL_AUTH_KEY' => 'Authorization Key',
  'PLG_TASK_REQUESTS_LABEL_REQUEST_TIMEOUT' => 'Request Timeout',
  'PLG_TASK_REQUESTS_LABEL_REQUEST_URL' => 'Request URL',
  'PLG_TASK_REQUESTS_TASK_GET_REQUEST_DESC' => 'Make GET requests to a server. Supports a custom timeout and authorization headers.',
  'PLG_TASK_REQUESTS_TASK_GET_REQUEST_LOG_RESPONSE' => 'Request response code was: %1$d',
  'PLG_TASK_REQUESTS_TASK_GET_REQUEST_LOG_TIMEOUT' => 'GET request failed or timed out.',
  'PLG_TASK_REQUESTS_TASK_GET_REQUEST_LOG_UNWRITEABLE_OUTPUT' => 'Unable write output file!',
  'PLG_TASK_REQUESTS_TASK_GET_REQUEST_ROUTINE_END_LOG_MESSAGE' => 'GET return code is: %1$d. Processing Time: %2$.2f seconds',
  'PLG_TASK_REQUESTS_TASK_GET_REQUEST_TITLE' => 'GET Request',
  'PLG_TASK_REQUESTS_XML_DESCRIPTION' => 'Job plugin to make GET requests to a server.',
);
