<?php
defined('_JEXEC') or die;
return array (
  'PLG_USER_TOKEN' => 'User - Joomla API Token',
  'PLG_USER_TOKEN_ALLOWEDUSERGROUPS_DESC' => 'Which Joomla User Groups are allowed to use Joomla Tokens to authenticate to the Joomla API application. Also controls which user groups see the Joomla Token management interface in their user profile. Default: Joomla\'s built-in Super Users group (User Group ID 8).',
  'PLG_USER_TOKEN_ALLOWEDUSERGROUPS_LABEL' => 'Allowed User Groups',
  'PLG_USER_TOKEN_XML_DESCRIPTION' => 'Allows the management of security tokens used for authenticating to the Joomla API application (remote access to your site). These tokens are strictly personal. You can view your own token but you can only disable or reset other users\' tokens.',
);
