<?php
defined('_JEXEC') or die;
return array (
  'PLG_KUNENA_FINDER' => 'Kunena - Finder Integration',
  'PLG_KUNENA_FINDER_DESCRIPTION' => 'Kunena Integration Plugin for Finder component.',
);
