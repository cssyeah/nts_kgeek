<?php
defined('_JEXEC') or die;
return array (
  'PLG_CONTENT_LOADMODULE' => 'Content - Load Modules',
  'PLG_LOADMODULE_XML_DESCRIPTION' => 'Within content this plugin loads a Module by ID, Syntax: {loadmoduleid 1} or a Module by position, Syntax: {loadposition user1} or a Module by name, Syntax: {loadmodule mod_login}. Optionally can specify module style and for loadmodule a specific module by title, Syntax: {loadmodule mod_login,module title,style}.',
);
