<?php
defined('_JEXEC') or die;
return array (
  'PLG_USER_TERMS' => 'User - Terms and Conditions',
  'PLG_USER_TERMS_FIELD_ARTICLE_DESC' => 'Select the article from the list or create a new one.',
  'PLG_USER_TERMS_FIELD_ARTICLE_LABEL' => 'Terms & Conditions Article',
  'PLG_USER_TERMS_FIELD_ERROR' => 'Agreement to the site\'s Terms & Conditions is required.',
  'PLG_USER_TERMS_FIELD_LABEL' => 'Terms & Conditions',
  'PLG_USER_TERMS_LABEL' => 'Terms & Conditions',
  'PLG_USER_TERMS_LOGGING_CONSENT_TO_TERMS' => 'User <a href=\'{accountlink}\' title=\'Edit user {username}\'>{username}</a> consented to the terms and conditions during registration.',
  'PLG_USER_TERMS_NOTE_FIELD_DEFAULT' => 'By signing up to this website you accept the Terms & Conditions.',
  'PLG_USER_TERMS_NOTE_FIELD_DESC' => 'A summary of the site\'s terms & conditions. If left blank then the default message will be used.',
  'PLG_USER_TERMS_NOTE_FIELD_LABEL' => 'Short Terms & Conditions',
  'PLG_USER_TERMS_OPTION_AGREE' => 'I agree',
  'PLG_USER_TERMS_OPTION_DO_NOT_AGREE' => 'I do not agree',
  'PLG_USER_TERMS_SUBJECT' => 'Privacy Policy',
  'PLG_USER_TERMS_XML_DESCRIPTION' => 'Basic plugin to request user\'s consent to the site\'s terms and conditions.',
);
