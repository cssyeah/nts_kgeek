<?php
defined('_JEXEC') or die;
return array (
  'COM_KUNENA_ALLREGISTERED' => 'All Registered',
  'COM_KUNENA_A_NO' => 'No',
  'COM_KUNENA_A_TEMPLATE_MANAGER_UNINSTALL' => 'Uninstall',
  'COM_KUNENA_A_YES' => 'Yes',
  'COM_KUNENA_DELETE_PERMANENTLY' => 'Delete',
  'COM_KUNENA_NOBODY' => 'Nobody',
  'COM_KUNENA_PUBLIC' => 'Public',
  'COM_KUNENA_TOPLEVEL' => 'Top Level',
  'COM_KUNENA_TRASH_MESSAGES' => 'Messages',
  'COM_KUNENA_TRASH_TOPICS' => 'Topics',
  'COM_KUNENA_TRASH_USERMESSAGES' => 'Trash Messages',
  'COM_KUNENA_UNPUBLISHED' => 'Unpublished',
  'COM_KUNENA_VIEW_PMS' => 'Click here to send a private message to this user.',
);
