<?php
defined('_JEXEC') or die;
return array (
  'COM_SCHEDULER' => 'Scheduled Tasks',
  'COM_SCHEDULER_ERROR_FORBIDDEN_JUMP_TO_ADD_VIEW' => 'You need to select a Task type first.',
  'COM_SCHEDULER_ERROR_INVALID_TASK_TYPE' => 'Invalid Task Type',
  'COM_SCHEDULER_MANAGER_TASK' => 'Task Manager',
  'COM_SCHEDULER_MANAGER_TASK_EDIT' => 'Edit Task',
  'COM_SCHEDULER_MANAGER_TASK_NEW' => 'New Task',
  'COM_SCHEDULER_MANAGER_TASKS' => 'Tasks Manager',
  'COM_SCHEDULER_MSG_MANAGE_NO_TASK_PLUGINS' => 'There are no task types matching your query.',
  'COM_SCHEDULER_TASKS_VIEW_DEFAULT_DESC' => 'Schedule and Manage Task Routines.',
  'COM_SCHEDULER_TASKS_VIEW_DEFAULT_TITLE' => 'Scheduled Tasks',
  'COM_SCHEDULER_XML_DESCRIPTION' => 'Component for managing scheduled tasks and cronjobs (if supported by the server).',
);
