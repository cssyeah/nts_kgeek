<?php
defined('_JEXEC') or die;
return array (
  'PLG_MULTIFACTORAUTH_YUBIKEY' => 'Multi-factor Authentication - YubiKey',
  'PLG_MULTIFACTORAUTH_YUBIKEY_XML_DESCRIPTION' => 'Allows users on your site to use Multi-factor Authentication using a YubiKey secure hardware token. Users need their own YubiKey available from <a href="https://www.yubico.com" target="_blank" rel="noopener noreferrer">www.yubico.com</a>. To use Multi-factor Authentication users have to edit their user profile and enable Multi-factor Authentication.',
);
