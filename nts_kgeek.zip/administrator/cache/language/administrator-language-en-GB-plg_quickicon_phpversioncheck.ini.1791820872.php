<?php
defined('_JEXEC') or die;
return array (
  'PLG_QUICKICON_PHPVERSIONCHECK' => 'Quick Icon - PHP Version Check',
  'PLG_QUICKICON_PHPVERSIONCHECK_SECURITY_ONLY' => 'Your PHP version, %1$s, is only receiving security fixes from the PHP project at this time. This means your PHP version will soon no longer be supported. We recommend planning to upgrade to a newer PHP version before it reaches end of support on %2$s. Joomla will be faster and more secure if you upgrade to a newer PHP version. Please contact your host for upgrade instructions.',
  'PLG_QUICKICON_PHPVERSIONCHECK_UNSUPPORTED' => 'We have detected that your server is using PHP %1$s which is obsolete and no longer receives official security updates by its developers. The Joomla! Project recommends upgrading your site to PHP %2$s or later which will receive security updates at least until %3$s. <br><br>Please ask your host to make PHP %2$s or a later version the default version for your site. If your host is already PHP %2$s ready please enable PHP %2$s on your site\'s root and \'administrator\' directories – typically you can do this yourself through a tool in your hosting control panel, but it\'s best to ask your host if you are unsure.',
  'PLG_QUICKICON_PHPVERSIONCHECK_UNSUPPORTED_JOOMLA_OUTDATED' => 'We have detected that your server is using PHP %1$s which is obsolete and no longer receives official security updates by its developers. Furthermore, we cannot recommend a newer PHP version because you are using an outdated Joomla! version. We recommend updating Joomla! and then following further PHP upgrade instructions.',
  'PLG_QUICKICON_PHPVERSIONCHECK_XML_DESCRIPTION' => 'Checks the support status of your installation\'s PHP version and raises a warning if not fully supported.',
);
