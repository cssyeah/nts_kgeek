<?php
defined('_JEXEC') or die;
return array (
  'PLG_FINDER_CONTENT' => 'Smart Search - Content',
  'PLG_FINDER_CONTENT_FIELD_SEARCH_ARCHIVED_DESC' => 'When changing this setting, you have to run the index command in Smart Search before this takes effect.',
  'PLG_FINDER_CONTENT_FIELD_SEARCH_ARCHIVED_LABEL' => 'Search Archived Content',
  'PLG_FINDER_CONTENT_TAXONOMIES_AUTHOR' => 'Author',
  'PLG_FINDER_CONTENT_TAXONOMIES_CATEGORY' => 'Category',
  'PLG_FINDER_CONTENT_TAXONOMIES_LABEL' => 'Taxonomies to Index',
  'PLG_FINDER_CONTENT_TAXONOMIES_LANGUAGE' => 'Language',
  'PLG_FINDER_CONTENT_TAXONOMIES_TYPE' => 'Type',
  'PLG_FINDER_CONTENT_XML_DESCRIPTION' => 'Updates the indexes of Joomla! Articles whenever an article is created, modified or deleted. NOTE the Content - Smart Search plugin must be enabled.',
  'PLG_FINDER_QUERY_FILTER_BRANCH_P_ARTICLE' => 'Articles',
  'PLG_FINDER_QUERY_FILTER_BRANCH_P_AUTHOR' => 'Authors',
  'PLG_FINDER_QUERY_FILTER_BRANCH_S_ARTICLE' => 'Article',
  'PLG_FINDER_QUERY_FILTER_BRANCH_S_AUTHOR' => 'Author',
);
