<?php
defined('_JEXEC') or die;
return array (
  'PLG_SYSTEM_KUNENA' => 'System - Kunena Forum',
  'PLG_SYSTEM_KUNENA_DESC' => 'Kunena System Plugin -- Please do not unpublish or uninstall',
  'PLG_SYSTEM_KUNENA_JCONTENTPLUGINS' => 'Joomla Content Plugin Support',
  'PLG_SYSTEM_KUNENA_JCONTENTPLUGINS_DESC' => 'Set to <em>Yes</em> if you want to enable all installed Joomla content plugins in your forum. This option allows you to add bad words filtering and much more. Just be careful not to allow users to run any unprivileged tasks.',
  'PLG_SYSTEM_KUNENA_JCONTENTPLUGINS_TARGET' => 'Run plugins on',
  'PLG_SYSTEM_KUNENA_JCONTENTPLUGINS_TARGET_DESC' => 'Which data do you want to run Joomla content plugins on? (Hold down CTRL key to click on more)',
  'PLG_SYSTEM_KUNENA_JCONTENTPLUGINS_TARGET_TITLES' => 'Titles',
  'PLG_SYSTEM_KUNENA_JCONTENTPLUGINS_TARGET_BODIES' => 'Bodies',
  'PLG_SYSTEM_KUNENA_STOPFORUMSPAMLISTED' => 'Registration failed. Please try again or contact the site administrator for assistance.',
);
