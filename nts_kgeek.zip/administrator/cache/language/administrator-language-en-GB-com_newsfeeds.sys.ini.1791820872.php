<?php
defined('_JEXEC') or die;
return array (
  'COM_NEWSFEEDS' => 'News Feeds',
  'COM_NEWSFEEDS_CATEGORIES' => 'Categories',
  'COM_NEWSFEEDS_CATEGORIES_VIEW_DEFAULT_DESC' => 'Shows a list of all categories in the selected news feed category tree.',
  'COM_NEWSFEEDS_CATEGORIES_VIEW_DEFAULT_OPTION' => 'Default',
  'COM_NEWSFEEDS_CATEGORIES_VIEW_DEFAULT_TITLE' => 'List All Categories in a News Feed Category Tree',
  'COM_NEWSFEEDS_CATEGORY_VIEW_DEFAULT_DESC' => 'Show all news feeds within a category.',
  'COM_NEWSFEEDS_CATEGORY_VIEW_DEFAULT_OPTION' => 'Default',
  'COM_NEWSFEEDS_CATEGORY_VIEW_DEFAULT_TITLE' => 'List News Feeds in a Category',
  'COM_NEWSFEEDS_CONTENT_TYPE_CATEGORY' => 'News Feed Category',
  'COM_NEWSFEEDS_CONTENT_TYPE_NEWSFEED' => 'News feed',
  'COM_NEWSFEEDS_FEEDS' => 'Feeds',
  'COM_NEWSFEEDS_NEWSFEED_VIEW_DEFAULT_DESC' => 'Show a single news feed.',
  'COM_NEWSFEEDS_NEWSFEED_VIEW_DEFAULT_OPTION' => 'Default',
  'COM_NEWSFEEDS_NEWSFEED_VIEW_DEFAULT_TITLE' => 'Single News Feed',
  'COM_NEWSFEEDS_TAGS_CATEGORY' => 'News Feed Category',
  'COM_NEWSFEEDS_TAGS_NEWSFEED' => 'News Feed',
  'COM_NEWSFEEDS_XML_DESCRIPTION' => 'This component manages RSS and Atom news feeds.',
);
