<?php
defined('_JEXEC') or die;
return array (
  'PLG_FINDER_KUNENA' => 'Smart Search - Kunena Forum',
  'PLG_FINDER_KUNENA_DESCRIPTION' => 'This plugin indexes Kunena Forum.',
);
