<?php
defined('_JEXEC') or die;
return array (
  'PLG_TASK_PRIVACYCONSENT' => 'Task - Privacy Consents',
  'PLG_TASK_PRIVACYCONSENT_CONSENTEXPIRATIONDAYS_DESC' => 'Number of days after which the privacy consent shall expire.',
  'PLG_TASK_PRIVACYCONSENT_CONSENTEXPIRATIONDAYS_LABEL' => 'Expiration',
  'PLG_TASK_PRIVACYCONSENT_INVALIDATE_TITLE' => 'Expiration of privacy consents',
  'PLG_TASK_PRIVACYCONSENT_INVALIDATE_DESC' => 'Manage the expiration of privacy consents',
  'PLG_TASK_PRIVACYCONSENT_EMAIL_REMIND_BODY' => 'Your Privacy Consent given at {URL} will expire in few days, you can renew the privacy consent for this website.\\n\\nIn order to do this, you can complete one of the following tasks:\\n\\n1. Visit the following URL: {TOKENURL}\\n\\n2. Copy your token from this email, visit the referenced URL, and paste your token into the form.\\nURL: {FORMURL}\\nToken: {TOKEN}\\n\\nPlease note that this token is only valid for this account.',
  'PLG_TASK_PRIVACYCONSENT_EMAIL_REMIND_SUBJECT' => 'Privacy Consent at {SITENAME}',
  'PLG_TASK_PRIVACYCONSENT_LOG_REMIND_END' => 'Remind End',
  'PLG_TASK_PRIVACYCONSENT_MAIL_REQUEST_REMINDER_DESC' => 'Reminder to renew the privacy consent for this website.',
  'PLG_TASK_PRIVACYCONSENT_MAIL_REQUEST_REMINDER_TITLE' => 'Task - Privacy Consent: Renew Consent',
  'PLG_TASK_PRIVACYCONSENT_NOTIFICATION_USER_PRIVACY_EXPIRED_MESSAGE' => 'Privacy consent has expired for %1$s.',
  'PLG_TASK_PRIVACYCONSENT_NOTIFICATION_USER_PRIVACY_EXPIRED_SUBJECT' => 'Privacy Consent Expired',
  'PLG_TASK_PRIVACYCONSENT_REMINDBEFORE_DESC' => 'Number of days to send a reminder before the expiration of the privacy consent.',
  'PLG_TASK_PRIVACYCONSENT_REMINDBEFORE_LABEL' => 'Remind',
  'PLG_TASK_PRIVACYCONSENT_XML_DESCRIPTION' => 'Task for remind expired consents and delete expired consents',
);
