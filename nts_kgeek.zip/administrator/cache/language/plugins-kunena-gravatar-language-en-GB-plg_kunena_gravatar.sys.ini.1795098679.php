<?php
defined('_JEXEC') or die;
return array (
  'PLG_KUNENA_GRAVATAR' => 'Kunena - Gravatar Integration',
  'PLG_KUNENA_GRAVATAR_DESCRIPTION' => 'Kunena Integration Plugin for Gravatars.',
  'PLG_KUNENA_GRAVATAR_AVATAR' => 'Enable Gravatars',
  'PLG_KUNENA_GRAVATAR_AVATAR_DESC' => 'Use Gravatar images in Kunena.',
  'PLG_KUNENA_GRAVATAR_DEFAULT_IMAGE' => 'Default image',
  'PLG_KUNENA_GRAVATAR_DEFAULT_IMAGE_DESC' => 'The default image to serve up when there is no Gravatar image associated with the requested email. Supply the URL of your own default image, or specify a built in option, such as identicon, monsterid, wavatar or retro.',
);
