<?php
defined('_JEXEC') or die;
return array (
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_MENUS_TITLE' => 'The Menu',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_MENUS_DESCRIPTION' => '<p>The menu provides access to the Administrator management pages. Each section has a collection of pages for managing that particular aspect of Joomla, such as Content, Menus and Users.</p><p>The window pane icons link to individual dashboards for those sections. The System menu itself leads to a dashboard.</p>',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_QUICKACCESS_TITLE' => 'The Dashboard Panels',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_QUICKACCESS_DESCRIPTION' => '<p>Dashboards provide quick access to frequently used pages via their icons.</p><p>Each dashboard panel is an Administrator module that can be customised via its Settings icon <span class="icon-cogs" aria-hidden="true"></span>.<br>This allows you to configure your site dashboards to suit your own purposes.</p>',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_NOTIFICATIONS_TITLE' => 'The Notifications Panel',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_NOTIFICATIONS_DESCRIPTION' => '<p>The Notifications panel shows when updates are available for Joomla and other extensions. Outstanding Privacy Requests are also shown here.</p>',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_TOPBAR_TITLE' => 'The Top Bar',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_TOPBAR_DESCRIPTION' => '<p>The top bar shows the title of the displayed page so that you always know where you are. The other items in the top bar are optional modules.</p><p>Typically the current Joomla version and access to further guided tours can be found here.</p><p>The last items are usually a link to the Site frontend and the User Menu where you can manage your account and logout.</p>',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_FINALWORDS_TITLE' => 'Help and Information',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_STEP_FINALWORDS_DESCRIPTION' => '<p>Many resources to help you can be found here together with additional links to more resources, documentation, support and how to become involved in Joomla.</p>',
);
