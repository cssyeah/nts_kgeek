<?php
defined('_JEXEC') or die;
return array (
  'COM_FINDER' => 'Smart Search',
  'COM_FINDER_FILTERS' => 'Filters',
  'COM_FINDER_FILTERS_VIEW_DEFAULT_DESC' => 'Display search filters.',
  'COM_FINDER_FILTERS_VIEW_DEFAULT_TITLE' => 'Smart Search Filters',
  'COM_FINDER_INDEX' => 'Index',
  'COM_FINDER_INDEX_VIEW_DEFAULT_DESC' => 'Display indexed content.',
  'COM_FINDER_INDEX_VIEW_DEFAULT_TITLE' => 'Smart Search Indexed Content',
  'COM_FINDER_MAPS' => 'Content Maps',
  'COM_FINDER_MAPS_VIEW_DEFAULT_DESC' => 'Display search content mapping.',
  'COM_FINDER_MAPS_VIEW_DEFAULT_TITLE' => 'Smart Search Content Mapping',
  'COM_FINDER_MENU_SEARCH_VIEW_DEFAULT_TEXT' => 'The default search layout.',
  'COM_FINDER_MENU_SEARCH_VIEW_DEFAULT_TITLE' => 'Search',
  'COM_FINDER_SEARCH_VIEW_DEFAULT_DESC' => 'Display search results.',
  'COM_FINDER_SEARCH_VIEW_DEFAULT_TITLE' => 'Smart Search results',
  'COM_FINDER_SEARCHES' => 'Search Terms',
  'COM_FINDER_STATS_VIEW_DEFAULT_DESC' => 'Display search statistics.',
  'COM_FINDER_STATS_VIEW_DEFAULT_TITLE' => 'Smart Search Statistics',
  'COM_FINDER_XML_DESCRIPTION' => 'Smart Search',
);
