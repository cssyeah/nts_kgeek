<?php
defined('_JEXEC') or die;
return array (
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_TITLE' => 'Welcome to Joomla!',
  'COM_GUIDEDTOURS_TOUR_WELCOMETOJOOMLA_DESCRIPTION' => '<p>This tour will give you a quick overview of how to get started with Joomla!</p><p>You are in the Joomla Administrator area, also known as the \'<strong>Backend</strong>\'.<br>This is where you set up and manage your entire Joomla Site.</p><p><strong>Want to learn more?</strong></p><p>Let\'s start the tour and build your site with the power of Joomla!</p>',
);
