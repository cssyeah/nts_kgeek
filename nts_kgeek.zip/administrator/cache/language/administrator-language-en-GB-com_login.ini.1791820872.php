<?php
defined('_JEXEC') or die;
return array (
  'COM_LOGIN' => 'Login',
  'COM_LOGIN_JOOMLA_ADMINISTRATION_LOGIN' => 'Joomla! Administration Login',
  'COM_LOGIN_RETURN_TO_SITE_HOME_PAGE' => 'Go to site home page',
  'COM_LOGIN_VALID' => 'Use a valid username and password to gain access to the Administrator Backend.',
  'COM_LOGIN_XML_DESCRIPTION' => 'This component lets users login to the site.',
);
