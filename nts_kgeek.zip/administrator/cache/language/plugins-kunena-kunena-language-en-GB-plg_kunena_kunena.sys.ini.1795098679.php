<?php
defined('_JEXEC') or die;
return array (
  'PLG_KUNENA_KUNENA' => 'Kunena - Kunena Integration',
  'PLG_KUNENA_KUNENA_DESCRIPTION' => 'Default Kunena Integration Plugin.',
  'PLG_KUNENA_KUNENA_AVATAR' => 'Enable Kunena Avatars',
  'PLG_KUNENA_KUNENA_AVATAR_DESC' => 'Use Kunena avatar images in Kunena.',
  'PLG_KUNENA_KUNENA_PROFILE' => 'Enable Kunena Profiles',
  'PLG_KUNENA_KUNENA_PROFILE_DESC' => 'Use Kunena profile pages and user list in Kunena.',
);
