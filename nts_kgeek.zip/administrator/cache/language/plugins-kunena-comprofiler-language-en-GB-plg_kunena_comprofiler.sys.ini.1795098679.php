<?php
defined('_JEXEC') or die;
return array (
  'PLG_KUNENA_COMPROFILER' => 'Kunena - Community Builder Integration',
  'PLG_KUNENA_COMPROFILER_DESCRIPTION' => 'Kunena Integration Plugin for Community Builder.',
  'PLG_KUNENA_COMPROFILER_ACCESSTYPE_GROUP' => 'GroupJive Groups',
  'PLG_KUNENA_COMPROFILER_ACCESS_GROUP_TITLE' => 'GroupJive Group:',
  'PLG_KUNENA_COMPROFILER_ACCESS_GROUP_DESC' => 'The GroupJive Group that is allowed to view this category.',
  'PLG_KUNENA_COMPROFILER_ACCESS' => 'Enable Access Control',
  'PLG_KUNENA_COMPROFILER_ACCESS_DESC' => 'Restrict Kunena category access for GroupJive group members in chosen categories. To use this option you need to install GroupJive plugin to Community Builder.',
  'PLG_KUNENA_COMPROFILER_LOGIN' => 'Enable Community Builder Login',
  'PLG_KUNENA_COMPROFILER_LOGIN_DESC' => 'Use Community Builder login and registration in Kunena.',
  'PLG_KUNENA_COMPROFILER_ACTIVITY' => 'Enable Activity Stream',
  'PLG_KUNENA_COMPROFILER_ACTIVITY_DESC' => 'Display Kunena events in Community Builder activity stream.',
  'PLG_KUNENA_COMPROFILER_AVATAR' => 'Enable Community Builder Avatars',
  'PLG_KUNENA_COMPROFILER_AVATAR_DESC' => 'Use Community Builder avatar images in Kunena.',
  'PLG_KUNENA_COMPROFILER_PROFILE' => 'Enable Community Builder Profiles',
  'PLG_KUNENA_COMPROFILER_PROFILE_DESC' => 'Use Community Builder profile pages and user list in Kunena.',
  'PLG_KUNENA_COMPROFILER_PRIVATE' => 'Enable Private Messages',
  'PLG_KUNENA_COMPROFILER_PRIVATE_DESC' => 'Use Community Builder private messaging integration in Kunena.',
  'PLG_KUNENA_COMPROFILER_WARN_VERSION' => 'Kunena - Community Builder Integration plugin only works as expected if you have Community Builder version %s or higher installed.',
  'COM_KUNENA_INTEGRATION_TYPE_COMMUNITYBUILDER' => 'Community Builder',
);
