<?php
defined('_JEXEC') or die;
return array (
  'PLG_CONTENT_PAGEBREAK' => 'Content - Page Break',
  'PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION' => '<p>Allow the creation of a paginated article with an optional table of contents.</p><p>Insert page breaks through the use of the page break button normally found in the WYSIWYG editor toolbar. The location of the page break in an article will be displayed in the editor as a simple horizontal line.</p><p>The text displayed will depend on the options chosen and may be either the title, alternate text (if provided) or page numbers.</p><p>The HTML usage is:<br>&lt;hr class=&quot;system-pagebreak&quot; /&gt;<br>&lt;hr class=&quot;system-pagebreak&quot; title=&quot;The page title&quot; /&gt; or <br>&lt;hr class=&quot;system-pagebreak&quot; alt=&quot;The first page&quot; /&gt; or <br>&lt;hr class=&quot;system-pagebreak&quot; title=&quot;The page title&quot; alt=&quot;The first page&quot; /&gt; or <br>&lt;hr class=&quot;system-pagebreak&quot; alt=&quot;The first page&quot; title=&quot;The page title&quot; /&gt;</p>',
);
