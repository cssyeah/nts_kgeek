<?php
defined('_JEXEC') or die;
return array (
  'PLG_FINDER_CONTACTS' => 'Smart Search - Contacts',
  'PLG_FINDER_CONTACTS_FIELD_SEARCH_ARCHIVED_DESC' => 'When changing this setting, you have to run the index command in Smart Search before this takes effect.',
  'PLG_FINDER_CONTACTS_FIELD_SEARCH_ARCHIVED_LABEL' => 'Search Archived Content',
  'PLG_FINDER_CONTACTS_TAXONOMIES_CATEGORY' => 'Category',
  'PLG_FINDER_CONTACTS_TAXONOMIES_COUNTRY' => 'Country',
  'PLG_FINDER_CONTACTS_TAXONOMIES_LABEL' => 'Taxonomies to Index',
  'PLG_FINDER_CONTACTS_TAXONOMIES_LANGUAGE' => 'Language',
  'PLG_FINDER_CONTACTS_TAXONOMIES_REGION' => 'Region',
  'PLG_FINDER_CONTACTS_TAXONOMIES_TYPE' => 'Type',
  'PLG_FINDER_CONTACTS_XML_DESCRIPTION' => 'This plugin indexes Joomla! Contacts.',
  'PLG_FINDER_QUERY_FILTER_BRANCH_P_CONTACT' => 'Contacts',
  'PLG_FINDER_QUERY_FILTER_BRANCH_P_COUNTRY' => 'Countries',
  'PLG_FINDER_QUERY_FILTER_BRANCH_P_REGION' => 'Regions',
  'PLG_FINDER_QUERY_FILTER_BRANCH_S_CONTACT' => 'Contact',
  'PLG_FINDER_QUERY_FILTER_BRANCH_S_COUNTRY' => 'Country',
  'PLG_FINDER_QUERY_FILTER_BRANCH_S_REGION' => 'Region',
);
