<?php
defined('_JEXEC') or die;
return array (
  'COM_ADMIN' => 'System Information',
  'COM_ADMIN_HELP_VIEW_DEFAULT_DESC' => 'Get help on various pages in your Joomla administrator interface.',
  'COM_ADMIN_HELP_VIEW_DEFAULT_TITLE' => 'Joomla! Help',
  'COM_ADMIN_SYSINFO_VIEW_DEFAULT_DESC' => 'View detailed information about your Joomla site and server configuration settings.',
  'COM_ADMIN_SYSINFO_VIEW_DEFAULT_TITLE' => 'System Information',
  'COM_ADMIN_XML_DESCRIPTION' => 'Administration system information component.',
);
