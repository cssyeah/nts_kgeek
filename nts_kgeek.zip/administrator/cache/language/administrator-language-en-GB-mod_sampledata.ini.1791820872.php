<?php
defined('_JEXEC') or die;
return array (
  'MOD_SAMPLEDATA' => 'Sample Data',
  'MOD_SAMPLEDATA_COMPLETED' => 'Sample data installed.',
  'MOD_SAMPLEDATA_CONFIRM_START' => 'Proceeding will install a sample data set into your Joomla website. This process can\'t be reverted once done.',
  'MOD_SAMPLEDATA_ERROR_RESPONSE' => 'Something went wrong! Please close and reopen the browser and try again!',
  'MOD_SAMPLEDATA_INVALID_RESPONSE' => 'There is an error in a sample data plugin. Response is invalid.',
  'MOD_SAMPLEDATA_ITEM_ALREADY_PROCESSED' => 'This sample data set is already installed.',
  'MOD_SAMPLEDATA_MANAGE_SAMPLEDATA' => 'Manage',
  'MOD_SAMPLEDATA_XML_DESCRIPTION' => 'This module lets you install sample data.',
);
