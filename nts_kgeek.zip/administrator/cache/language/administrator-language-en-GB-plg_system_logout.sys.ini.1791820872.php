<?php
defined('_JEXEC') or die;
return array (
  'PLG_SYSTEM_LOGOUT' => 'System - Logout',
  'PLG_SYSTEM_LOGOUT_XML_DESCRIPTION' => 'The system logout plugin enables Joomla to redirect the user to the home page if they choose to logout while they are on a protected access page.',
);
