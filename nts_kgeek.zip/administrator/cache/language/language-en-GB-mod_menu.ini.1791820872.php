<?php
defined('_JEXEC') or die;
return array (
  'MOD_MENU' => 'Menu',
  'MOD_MENU_FIELD_ACTIVE_LABEL' => 'Base Item',
  'MOD_MENU_FIELD_ALLCHILDREN_LABEL' => 'Sub-menu Items',
  'MOD_MENU_FIELD_CLASS_LABEL' => 'Menu Class',
  'MOD_MENU_FIELD_ENDLEVEL_LABEL' => 'End Level',
  'MOD_MENU_FIELD_MENUTYPE_LABEL' => 'Select Menu',
  'MOD_MENU_FIELD_STARTLEVEL_LABEL' => 'Start Level',
  'MOD_MENU_FIELD_TAG_ID_LABEL' => 'Menu Tag ID',
  'MOD_MENU_FIELD_TARGET_DESC' => 'JavaScript values to position a popup window, eg top=50, left=50, width=200, height=300.',
  'MOD_MENU_FIELD_TARGET_LABEL' => 'Target Position',
  'MOD_MENU_TOGGLE' => 'Toggle Navigation',
  'MOD_MENU_TOGGLE_SUBMENU_LABEL' => 'More about: %s',
  'MOD_MENU_XML_DESCRIPTION' => 'This module displays a menu on the Frontend.',
);
