<?php
defined('_JEXEC') or die;
return array (
  'MOD_LOGINSUPPORT' => 'Login Support Information',
  'MOD_LOGINSUPPORT_DOCUMENTATION' => 'Joomla! Documentation',
  'MOD_LOGINSUPPORT_FIELD_DOCUMENTATION_URL_LABEL' => 'Documentation URL',
  'MOD_LOGINSUPPORT_FIELD_FORUM_URL_LABEL' => 'Forum URL',
  'MOD_LOGINSUPPORT_FIELD_NEWS_URL_LABEL' => 'News URL',
  'MOD_LOGINSUPPORT_FORUM' => 'Joomla! Support Forum',
  'MOD_LOGINSUPPORT_HEADLINE' => 'You can find help here:',
  'MOD_LOGINSUPPORT_NEWS' => 'Joomla! News',
  'MOD_LOGINSUPPORT_TITLE' => 'Need Support?',
  'MOD_LOGINSUPPORT_XML_DESCRIPTION' => 'This module displays some useful links to Joomla support sites on the login screen.',
);
