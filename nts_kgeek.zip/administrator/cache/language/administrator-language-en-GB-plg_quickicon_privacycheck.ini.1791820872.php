<?php
defined('_JEXEC') or die;
return array (
  'PLG_QUICKICON_PRIVACYCHECK' => 'Quick Icon - Joomla! Privacy Requests Notification',
  'PLG_QUICKICON_PRIVACYCHECK_CHECKING' => 'Checking requests &hellip;',
  'PLG_QUICKICON_PRIVACYCHECK_ERROR' => 'Unknown requests &hellip;',
  'PLG_QUICKICON_PRIVACYCHECK_GROUP_DESC' => 'The group of this plugin (this value is compared with the group value used in <strong>Quick Icons</strong> modules to inject icons).',
  'PLG_QUICKICON_PRIVACYCHECK_GROUP_LABEL' => 'Group',
  'PLG_QUICKICON_PRIVACYCHECK_NOREQUEST' => 'No urgent privacy requests.',
  'PLG_QUICKICON_PRIVACYCHECK_REQUESTFOUND' => 'Urgent privacy requests!',
  'PLG_QUICKICON_PRIVACYCHECK_REQUESTFOUND_BUTTON' => 'View Requests',
  'PLG_QUICKICON_PRIVACYCHECK_REQUESTFOUND_MESSAGE' => '%s Urgent Privacy Request(s) to manage.',
  'PLG_QUICKICON_PRIVACYCHECK_XML_DESCRIPTION' => 'Checks for privacy requests that need to be handled and notifies you when you visit the Home Dashboard.',
);
