<?php
defined('_JEXEC') or die;
return array (
  'COM_FIELDS' => 'Fields',
  'COM_FIELDS_CHOOSE_COMPONENT_LABEL' => 'Choose a Component',
  'COM_FIELDS_FIELDS_VIEW_DEFAULT_DESC' => 'Shows a list of all the fields.',
  'COM_FIELDS_FIELDS_VIEW_DEFAULT_TITLE' => 'List All Fields',
  'COM_FIELDS_GROUPS_VIEW_DEFAULT_DESC' => 'Shows a list of all the field groups.',
  'COM_FIELDS_GROUPS_VIEW_DEFAULT_TITLE' => 'List All Field Groups',
  'COM_FIELDS_XML_DESCRIPTION' => 'Component to manage custom fields.',
);
