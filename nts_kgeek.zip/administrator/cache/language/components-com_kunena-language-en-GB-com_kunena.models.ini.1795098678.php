<?php
defined('_JEXEC') or die;
return array (
  'COM_KUNENA_APPROVE_SELECTED' => 'Approve selected',
  'COM_KUNENA_BULK_CHOOSE_ACTION' => '- Choose Action -',
  'COM_KUNENA_BUTTON_PERMDELETE_LONG' => 'Permanent Delete selected',
  'COM_KUNENA_BUTTON_UNDELETE_LONG' => 'Undelete selected',
  'COM_KUNENA_DELETE_SELECTED' => 'Delete selected',
  'COM_KUNENA_MOVE_SELECTED' => 'Move selected',
  'COM_KUNENA_UNSUBSCRIBE_SELECTED' => 'Unsubscribe selected',
  'COM_KUNENA_BULK_ANNOUNCEMENT_PUBLISH' => 'Publish',
  'COM_KUNENA_BULK_ANNOUNCEMENT_UNPUBLISH' => 'Unpublish',
  'COM_KUNENA__BULK_ANNOUNCEMENT_DELETE' => 'Delete',
  'COM_KUNENA_GEN_SEARCH_BOX' => 'Search Forum',
  'COM_KUNENA_SEARCH_ERR_NOPOSTS' => 'No messages containing all your search terms were found.',
  'COM_KUNENA_SEARCH_ERR_SHORTKEYWORD' => 'At least one keyword should be over three characters long.',
  'COM_KUNENA_SEARCH_NORESULTS_FOUND' => 'Your search %s did not match any topics.',
  'COM_KUNENA_UNFAVORITE_SELECTED' => 'Unfavorite selected',
);
