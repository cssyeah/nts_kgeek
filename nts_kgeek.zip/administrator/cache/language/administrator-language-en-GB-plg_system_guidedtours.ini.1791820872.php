<?php
defined('_JEXEC') or die;
return array (
  'PLG_SYSTEM_GUIDEDTOURS' => 'System - Guided Tours Plugin',
  'PLG_SYSTEM_GUIDEDTOURS_BACK' => 'Back',
  'PLG_SYSTEM_GUIDEDTOURS_COMPLETE' => 'Complete',
  'PLG_SYSTEM_GUIDEDTOURS_COULD_NOT_LOAD_THE_TOUR' => 'Could not start the tour. No valid ID given.',
  'PLG_SYSTEM_GUIDEDTOURS_DESCRIPTION' => 'System Guided Tour Plugin',
  'PLG_SYSTEM_GUIDEDTOURS_HIDE_FOREVER' => 'Hide Forever',
  'PLG_SYSTEM_GUIDEDTOURS_NEXT' => 'Next',
  'PLG_SYSTEM_GUIDEDTOURS_START' => 'Start',
  'PLG_SYSTEM_GUIDEDTOURS_STEP_NUMBER_OF' => 'Step {number} of {total}',
  'PLG_SYSTEM_GUIDEDTOURS_TOUR_ERROR' => 'Oh no! It looks like your tour is off track. The tour exited and cannot run.',
  'PLG_SYSTEM_GUIDEDTOURS_TOUR_ERROR_RESPONSE' => 'Something went wrong while saving tour state information! Response error.',
  'PLG_SYSTEM_GUIDEDTOURS_TOUR_INVALID_RESPONSE' => 'Something went wrong while saving tour state information! Response is invalid.',
);
