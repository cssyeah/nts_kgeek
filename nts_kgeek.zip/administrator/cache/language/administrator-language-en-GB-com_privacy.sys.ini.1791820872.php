<?php
defined('_JEXEC') or die;
return array (
  'COM_PRIVACY' => 'Privacy',
  'COM_PRIVACY_CONFIRM_VIEW_DEFAULT_DESC' => 'Displays a form to confirm an information request.',
  'COM_PRIVACY_CONFIRM_VIEW_DEFAULT_OPTION' => 'Default',
  'COM_PRIVACY_CONFIRM_VIEW_DEFAULT_TITLE' => 'Confirm Request',
  'COM_PRIVACY_CONSENTS_VIEW_DEFAULT_DESC' => 'Shows a list of user consents',
  'COM_PRIVACY_CONSENTS_VIEW_DEFAULT_TITLE' => 'Privacy: Consents',
  'COM_PRIVACY_DASHBOARD_VIEW_DEFAULT_DESC' => 'A dashboard related to the site\'s privacy settings and information requests.',
  'COM_PRIVACY_DASHBOARD_VIEW_DEFAULT_TITLE' => 'Privacy: Dashboard',
  'COM_PRIVACY_REMIND_VIEW_DEFAULT_DESC' => 'Displays a form to extend the privacy consent',
  'COM_PRIVACY_REMIND_VIEW_DEFAULT_TITLE' => 'Extend Consent',
  'COM_PRIVACY_REQUEST_VIEW_DEFAULT_DESC' => 'Displays a form to submit an information request.',
  'COM_PRIVACY_REQUEST_VIEW_DEFAULT_OPTION' => 'Default',
  'COM_PRIVACY_REQUEST_VIEW_DEFAULT_TITLE' => 'Create Request',
  'COM_PRIVACY_REQUESTS_VIEW_DEFAULT_DESC' => 'Shows a list of user information requests',
  'COM_PRIVACY_REQUESTS_VIEW_DEFAULT_TITLE' => 'Privacy: Information Requests',
  'COM_PRIVACY_XML_DESCRIPTION' => 'Component for managing privacy related actions.',
);
