<?php
defined('_JEXEC') or die;
return array (
  'PLG_PRIVACY_KUNENA' => 'Privacy - Kunena',
  'PLG_PRIVACY_KUNENA_DESCRIPTION' => 'Kunena - Export and Remove privacy related content for users',
);
