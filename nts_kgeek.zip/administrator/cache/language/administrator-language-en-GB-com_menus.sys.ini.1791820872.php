<?php
defined('_JEXEC') or die;
return array (
  'COM_MENUS' => 'Menus',
  'COM_MENUS_ITEM_VIEW_EDIT_DESC' => 'Shows a form to create a new menu item',
  'COM_MENUS_ITEM_VIEW_EDIT_TITLE' => 'New Menu Item',
  'COM_MENUS_ITEMS_CHOOSE_MENU_DESC' => 'Choose a Menutype for the target page.<br><br>Not to be confused with the <strong>Menu</strong> under which this menu item will be assigned.',
  'COM_MENUS_ITEMS_CHOOSE_MENU_LABEL' => 'Choose a Menutype',
  'COM_MENUS_ITEMS_VIEW_DEFAULT_DESC' => 'Shows a list of menu items',
  'COM_MENUS_ITEMS_VIEW_DEFAULT_TITLE' => 'Menu Items',
  'COM_MENUS_MENU_VIEW_EDIT_DESC' => 'Shows a form to create a new menu',
  'COM_MENUS_MENU_VIEW_EDIT_TITLE' => 'New Menu',
  'COM_MENUS_MENUS_PRESET_ALTERNATE' => 'Preset - Alternative Main Menu',
  'COM_MENUS_MENUS_PRESET_COMPONENTS' => 'Preset - Components Dashboard',
  'COM_MENUS_MENUS_PRESET_DEFAULT' => 'Preset - Joomla Main Menu',
  'COM_MENUS_MENUS_PRESET_HELP' => 'Preset - Help Dashboard',
  'COM_MENUS_MENUS_PRESET_MENUS' => 'Preset - Menus Dashboard',
  'COM_MENUS_MENUS_PRESET_SYSTEM' => 'Preset - System Dashboard',
  'COM_MENUS_MENUS_VIEW_DEFAULT_DESC' => 'Shows a list of Menu Types',
  'COM_MENUS_MENUS_VIEW_DEFAULT_TITLE' => 'Menus',
  'COM_MENUS_XML_DESCRIPTION' => 'Component for creating menus.',
);
