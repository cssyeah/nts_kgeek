<?php
defined('_JEXEC') or die;
return array (
  'COM_LANGUAGES' => 'Languages',
  'COM_LANGUAGES_INSTALLED_VIEW_DEFAULT_DESC' => 'Displays language packs installed into your Joomla! website.',
  'COM_LANGUAGES_INSTALLED_VIEW_DEFAULT_TITLE' => 'Installed Languages',
  'COM_LANGUAGES_LANGUAGES_VIEW_DEFAULT_DESC' => 'Create or manage content languages for your Joomla! website.',
  'COM_LANGUAGES_LANGUAGES_VIEW_DEFAULT_TITLE' => 'Content Languages',
  'COM_LANGUAGES_OVERRIDE_VIEW_DEFAULT_DESC' => 'Here you assign custom text for a language key that you want to use instead of language pack default text.',
  'COM_LANGUAGES_OVERRIDE_VIEW_DEFAULT_TITLE' => 'Language Overrides',
  'COM_LANGUAGES_XML_DESCRIPTION' => 'Component for language management.',
);
