<?php
defined('_JEXEC') or die;
return array (
  'PLG_SYSTEM_ACTIONLOGS' => 'System - User Actions Log',
  'PLG_SYSTEM_ACTIONLOGS_EXTENSIONS_NOTIFICATIONS' => 'Events to Email',
  'PLG_SYSTEM_ACTIONLOGS_INFO_DESC' => 'The Action Log - Joomla plugin is disabled',
  'PLG_SYSTEM_ACTIONLOGS_INFO_LABEL' => 'Information',
  'PLG_SYSTEM_ACTIONLOGS_JOOMLA_ACTIONLOG_DISABLED' => 'Action Log - Joomla',
  'PLG_SYSTEM_ACTIONLOGS_JOOMLA_ACTIONLOG_DISABLED_REDIRECT' => 'The %s plugin is disabled.',
  'PLG_SYSTEM_ACTIONLOGS_NOTIFICATIONS' => 'Email Notifications',
  'PLG_SYSTEM_ACTIONLOGS_OPTIONS' => 'User Actions Log Options',
  'PLG_SYSTEM_ACTIONLOGS_XML_DESCRIPTION' => 'Records the actions of users on the site so they can be reviewed if required.',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_ADDED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> added new {type} <a href="{itemlink}" title="Edit {type} {title}">{title}</a>',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_ARCHIVED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> archived the {type} <a href="{itemlink}" title="Edit {type} {title}">{title}</a>',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_DELETED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> deleted the {type} {title}',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_PUBLISHED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> published the {type} <a href="{itemlink}" title="Edit {type} {title}">{title}</a>',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_TRASHED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> trashed the {type} <a href="{itemlink}" title="Edit {type} {title}">{title}</a>',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_UNPUBLISHED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> unpublished the {type} <a href="{itemlink}" title="Edit {type} {title}">{title}</a>',
  'PLG_SYSTEM_ACTIONLOGS_CONTENT_UPDATED' => 'User <a href="{accountlink}" title="Edit User {username}">{username}</a> updated the {type} <a href="{itemlink}" title="Edit {type} {title}">{title}</a>',
);
