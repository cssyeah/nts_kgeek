<?php
defined('_JEXEC') or die;
return array (
  'PLG_QUICKICON_KUNENA' => 'Quick Icon - Kunena Forum',
  'PLG_QUICKICON_KUNENA_DESC' => 'Links to Kunena Forum and displays if there are updates when you visit the Control Panel page.',
  'PLG_QUICKICON_KUNENA_UPDATE_ADDONS' => 'Update %d add-ons!',
  'PLG_QUICKICON_KUNENA_UPDATE_NOW' => 'Update now!',
  'PLG_QUICKICON_KUNENA_UPDATE_DISABLED' => 'Updates disabled',
  'PLG_QUICKICON_KUNENA_COMPLETE_INSTALLATION' => 'Please complete Kunena installation!',
  'PLG_QUICKICON_KUNENA_GROUP_DESC' => 'The group of this plugin (this value is compared with the group value used in \'Quick Icons\' modules to inject icons)',
  'PLG_QUICKICON_KUNENA_GROUP_LABEL' => 'Group',
);
