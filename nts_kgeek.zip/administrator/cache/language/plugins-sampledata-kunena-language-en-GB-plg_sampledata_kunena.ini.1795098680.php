<?php
defined('_JEXEC') or die;
return array (
  'PLG_SAMPLEDATA_KUNENA' => 'Sample Data - Kunena Forum',
  'PLG_SAMPLEDATA_KUNENA_DESC' => 'Install sample data to your new forum.',
  'PLG_SAMPLEDATA_KUNENA_OVERVIEW_TITLE' => 'Kunena Forum Sample Data',
  'PLG_SAMPLEDATA_KUNENA_OVERVIEW_DESC' => 'Install Sample Data - Kunena Forum',
  'PLG_SAMPLEDATA_KUNENA_STEP1_SUCCESS' => 'The sampledata has been installed successfully',
);
