<?php
defined('_JEXEC') or die;
return array (
  'PLG_DEBUG_XML_DESCRIPTION' => 'This plugin provides a variety of system information and help for the creation of translation files.',
  'PLG_SYSTEM_DEBUG' => 'System - Debug',
);
