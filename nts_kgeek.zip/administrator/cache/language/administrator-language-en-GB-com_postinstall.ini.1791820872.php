<?php
defined('_JEXEC') or die;
return array (
  'COM_POSTINSTALL' => 'Post-installation Messages',
  'COM_POSTINSTALL_BTN_ARCHIVE' => 'Archive',
  'COM_POSTINSTALL_BTN_HIDE' => 'Hide this message',
  'COM_POSTINSTALL_BTN_REPUBLISH' => 'Read Again',
  'COM_POSTINSTALL_CONFIGURATION' => 'Post-installation Messages: Options',
  'COM_POSTINSTALL_EMPTYSTATE_BUTTON_ADD' => 'Reset Messages',
  'COM_POSTINSTALL_EMPTYSTATE_CONTENT' => 'You have read all the messages.',
  'COM_POSTINSTALL_EMPTYSTATE_TITLE' => 'Post-installation and Upgrade Messages',
  'COM_POSTINSTALL_HIDE_ALL_MESSAGES' => 'Hide all Messages',
  'COM_POSTINSTALL_LBL_SINCEVERSION' => 'Since version %s',
  'COM_POSTINSTALL_MESSAGES_FOR' => 'Showing messages for',
  'COM_POSTINSTALL_MESSAGES_TITLE' => 'Post-installation Messages for %s',
  'COM_POSTINSTALL_XML_DESCRIPTION' => 'Displays post-installation and post-upgrade messages for Joomla and its extensions.',
);
