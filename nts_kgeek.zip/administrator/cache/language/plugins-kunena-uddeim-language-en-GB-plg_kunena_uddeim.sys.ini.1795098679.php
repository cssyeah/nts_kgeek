<?php
defined('_JEXEC') or die;
return array (
  'PLG_KUNENA_UDDEIM' => 'Kunena - UddeIM Integration',
  'PLG_KUNENA_UDDEIM_DESCRIPTION' => 'Kunena Integration Plugin for UddeIM.',
  'PLG_KUNENA_UDDEIM_PRIVATE' => 'Enable Private Messages',
  'PLG_KUNENA_UDDEIM_PRIVATE_DESC' => 'Use UddeIM private messaging system in Kunena.',
);
