<?php
defined('_JEXEC') or die;
return array (
  'PLG_TASK_KUNENA' => 'Task - Kunena Forum',
  'PLG_TASK_KUNENA_DESCRIPTION' => 'Kunena Task Plugin -- Please do not unpublish or uninstall',
);
