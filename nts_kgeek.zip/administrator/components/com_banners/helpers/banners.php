<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_banners
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @phpcs:disable PSR1.Classes.ClassDeclaration.MissingNamespace
 */

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Banners component helper.
 *
 * @since       1.6
 *
 * @deprecated  4.3 will be removed in 7.0
 *              Use \Joomla\Component\Banners\Administrator\Helper\BannersHelper instead
 */
class BannersHelper extends \Joomla\Component\Banners\Administrator\Helper\BannersHelper
{
}
